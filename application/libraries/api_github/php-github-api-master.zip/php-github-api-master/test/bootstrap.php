<?php

require_once dirname(__FILE__).'/../lib/Github/Autoloader.php';
Github_Autoloader::register();
